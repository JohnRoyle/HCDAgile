# This is the default new book content

Please note that the manuscript folder is actually something which needs to live in your repository.

So, you **paste the manuscript folder itself** into your repository, not just the contents of the manuscript folder.
